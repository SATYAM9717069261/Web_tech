document.getElementsByClassName('inlineCheckbox1').addEventListener('click',add_data);
function add_data(){
    alert("Satam");
}

